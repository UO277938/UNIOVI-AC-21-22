#include <stdio.h>
#include <stdlib.h>
#include <errno.h>
#include <math.h>
#include <time.h>

const unsigned long nElements = 10000;
const unsigned long nTimes = 3000;

void Task(unsigned long nElements, unsigned long nTimes);
double Asin(double n);
double Atan(double n);
double Sinh(double n);
double Tanh(double n);

int main(int argc, char* argv[])
{

	// The single thread of the process runs the task
	Task(nElements,nTimes);

	printf("Execution finished\n");

	return 0;
}

double getRandom(unsigned int min, unsigned int max)
{
	// Pseudo-random numbers in the interval [min,max]
	return min + (max - min) * ((double)rand()/(double)RAND_MAX);
}

void Task(unsigned long nElements, unsigned long nTimes)
{
	unsigned long i, j;
	static unsigned int seed = 0;

	double *pdSrc1 = (double*)malloc(nElements * sizeof(double));
	double *pdDest = (double*)malloc(nElements * sizeof(double));
	if (pdSrc1 == NULL || pdDest == NULL)
	{
		free(pdSrc1);
		free(pdDest);
		printf("ERROR in Task: Cannot allocate memory\n");
		return;
	}

	srand(seed++);
	for (i = 0; i < nElements; i++)
	{
		// Pseudo-random numbers in the interval [1.0-4.0]
		pdSrc1[i] = getRandom(1,2);
	}

	for (j = 0; j < nTimes; j++)
	{
		for (i = 0; i < nElements; i++)
		{
			pdDest[i] = asin(pdSrc1[i]);

			pdDest[i] = atan(pdSrc1[i]);

			pdDest[i] = sinh(pdSrc1[i]);

			pdDest[i] = tanh(pdSrc1[i]);
		}
	}

	free(pdSrc1);
 	free(pdDest);
}

double Asin(double n)
{
	return asin(n);
}

double Atan(double n)
{
	return atan(n);
}

double Sinh(double n)
{
	return sinh(n);
}

double Tanh(double n)
{
	return tanh(n);
}
