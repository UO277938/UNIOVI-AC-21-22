#include <stdio.h> 
#include <stdlib.h> 
#include <errno.h> 
#include <math.h>
#include <time.h>


/****************************************************************************
* IMPORTANT NOTE FOR STUDENTS:
  ----------------------------
  USE THIS OPTION FOR A SINGLE-THREADED OR MULTI-THREADED VERSION:
  - Leave commented the following line to launch single-threaded version of the program
  - Uncomment the following line to launch multi-threaded version of the program
*****************************************************************************/
//#define MULTI_THREADED  

const unsigned int X_DIM = 900;
const unsigned int Y_DIM = 1600;
const unsigned long nElements = 10000;
const unsigned long nTimes = 4;
const unsigned int MAX_THREADS = 20;

double InvSinHyperbolic(double param);
void GaussianMask(unsigned int width, unsigned int heigth, double *kernel);
double DivideLog10(double *param1, double *param2);
void Task(unsigned long nElements, unsigned long nTimes);


#ifdef MULTI_THREADED
#include <pthread.h>

	void * ThreadJob(void * dummy)
	{
		Task(nElements, nTimes);
		return NULL;
	}
#endif


int main(int argc, char* argv[])
{
	struct timespec timeInit, timeEnd;
	double timeElapsed;
	
	
#ifdef MULTI_THREADED
	if (argc != 2)
	{
		fprintf(stderr, "Usage: %s <thread_count>\n", argv[0]);
		exit(EXIT_FAILURE);
	}
	unsigned int nThreads = atoi(argv[1]);
	if ((nThreads <= 0) || (nThreads > MAX_THREADS))
	{
		fprintf(stderr, "ERROR: thread count should be between [1,20]\n");
		exit(EXIT_FAILURE);
	}

	printf("Running with %d thread(s)...\n", nThreads);
#endif

	// Start measuring time
	// TODO: Write here the appropiate instructions to start time measurement
	if(clock_gettime(CLOCK_REALTIME, &timeInit) == -1){
		printf("ERROR: clock_gettime: %d.\n",errno);
		exit(EXIT_FAILURE);
	}

#ifdef MULTI_THREADED	
	pthread_t Threads[nThreads];

	// Start threads
	for (int i = 0; i < nThreads; i++)
	{
		int pthread_ret = pthread_create(&Threads[i], NULL, ThreadJob, NULL);
		if (pthread_ret)
		{
			fprintf(stderr, "ERROR: pthread_create error code: %d.\n", pthread_ret);
			exit(EXIT_FAILURE);
		}
	}

	// Wait for the threads to finish
	for (int i = 0; i < nThreads; i++)
	{
		pthread_join(Threads[i], NULL);
	}
#else
	// The single thread of the process runs the task
	Task(nElements,nTimes);
#endif

	// Finish measuring time
    // TODO: Write here the appropiate instructions to finish time measurement
	if (clock_gettime(CLOCK_REALTIME, &timeEnd) == -1){
		printf("ERROR: clock_gettime: %d.\n",errno);
		exit(EXIT_FAILURE);
	}
	
	

	printf("Execution finished\n");

	// Show the elapsed time
	// TODO: Write here the appropiate instructions to calculate the measured time
	timeElapsed= (timeEnd.tv_sec - timeInit.tv_sec);
   	timeElapsed+= (timeEnd.tv_nsec - timeInit.tv_nsec) / 1e+9;
	
	printf("Elapsed time    : %f s.\n", timeElapsed);
	
	return 0;
}

double getRandom(unsigned int min, unsigned int max)
{
	// Pseudo-random numbers in the interval [min,max]
	return min + (max - min) * ((double)rand()/(double)RAND_MAX);
}

void GaussianMask(unsigned int width, unsigned int heigth, double *kernel)
{
	double *pImg;	
	
	pImg = (double *) malloc(width * heigth * sizeof(double));
	srand(0);
	
	for (int i=0; i<width * heigth; i++)
		*(pImg + i)= getRandom(0, 255);
	
	for (int i=1; i<width; i++)
		for (int j=1; j<heigth; j++)
			*(pImg + j*heigth + i) = 
				kernel[0]* *(pImg + (j-1)*heigth + (i-1)) + 
				kernel[1]* *(pImg + (j-1)*heigth + i) + 
				kernel[2]* *(pImg + (j-1)*heigth + (i+1)) + 
				kernel[3]* *(pImg + j*heigth + (i-1)) + 
				kernel[4]* *(pImg + j*heigth + i) + 
				kernel[5]* *(pImg + j*heigth + (i+1)) + 
				kernel[6]* *(pImg + (j+1)*heigth + (i-1)) + 
				kernel[7]* *(pImg + (j+1)*heigth + i) + 
				kernel[8]* *(pImg + (j+1)*heigth + (i+1));
}

double Log10Divide( double *param1, double *param2) 
{
	return(log10(*param1)/(*param2));
}

double InvSinHyperbolic(double param) 
{
		return(1/sinh(param));
}

void Task(unsigned long nElements, unsigned long nTimes)
{
	unsigned long i, j;
	static unsigned int seed = 0;

	double *pdSrc1 = (double*)malloc(nElements * sizeof(double));
	double *pdSrc2 = (double*)malloc(nElements * sizeof(double));
	double *pdDest = (double*)malloc(nElements * sizeof(double));
	if (pdSrc1 == NULL || pdSrc2 == NULL || pdDest == NULL)
	{
		free(pdSrc1);
		free(pdSrc2);
		free(pdDest);
		printf("ERROR in Task: Cannot allocate memory\n");
		return;
	}

	srand(seed++);
	for (i = 0; i < nElements; i++)
	{
		// Pseudo-random numbers in the interval [1.0-10.0]
		pdSrc1[i] = getRandom(1,5);
		pdSrc2[i] = getRandom(6,10);
	}
	
	double filter[] ={1.0,2.0,1.0,
					 2.0,8.0,2.0,
					 1.0,2.0,1.0};
	
	
	for (j = 0; j < nTimes; j++)
	{
		GaussianMask(Y_DIM, X_DIM, filter);
		
		for (i = 0; i < nElements; i++)
		{
			pdDest[i] = Divide(&pdSrc2[i], &pdSrc2[i]);

			pdDest[i] = InvSinHyperbolic(pdSrc1[i]);
			
			pdDest[i] = (pdDest[i] * cbrt(pdSrc1[i])) / sqrt(pdSrc2[i]);		
						
		}
		
	}

	free(pdSrc1);
	free(pdSrc2);
 	free(pdDest);
}



